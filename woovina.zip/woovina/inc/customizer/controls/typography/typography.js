(function($) {

	$(document).ready(function () {

		$('.woovina-typography-select').select2();

	});

})(jQuery);