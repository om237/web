<?php
/**
 * The template for displaying the footer in PWA.
 *
 * @package WooVina WordPress theme
 * @since   4.7.5
 */

?>

	<?php wp_footer(); ?>
	</body>
</html>
